# QUEST LIFE 5.0 — Android project

A self-contained Android WebView application. The complete app interface and logic are in `app/src/main/assets/index.html`; Android-specific image selection, vibration and daily reminder scheduling are in the Java activity and receiver.

## Build an APK on GitHub

1. Create or open a GitHub repository.
2. Upload **the contents of this folder** to the repository root (including the hidden `.github` folder). Do not upload only the ZIP archive.
3. Open **Actions**.
4. Select **Build QUEST LIFE 5.0 APK** and choose **Run workflow** (or push to `main` / `master`).
5. Open the completed workflow run and download the artifact named `QUEST-LIFE-5.0-APK`.
6. Extract the artifact ZIP to obtain `app-debug.apk`, then install it on an Android device. If Android asks, allow installation from that source.

## Project configuration

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (provided by GitHub Actions)
- JDK: 17
- Compile SDK: 35 • Target SDK: 34
- Minimum Android SDK: 23 (Android 6.0)
- Application ID: `com.questlife.app.debug` for the debug APK

## Included features

- First-run language choice (Arabic / English) and player profile setup.
- Home dashboard, XP and gold counters, user-defined task and challenge rewards.
- Tasks with due dates, category, description, edit/delete/complete/undo.
- Challenges with independent subtasks and one-time completion rewards.
- Habit monthly grids, daily check-ins, streak and monthly completion rate.
- Monthly calendar with daily task details and completion status.
- Profile photo and custom background selection, crop/zoom/position adjustment, and customizable illustrated avatar.
- Achievements, user-created reward shop, local backup export and restore.
- Sound effect toggle and volume control with bundled local WAV files.
- Optional Android daily reminder (notification permission requested when enabled).
- Local persistence using WebView DOM storage.

## Design decisions

- The default theme is dark with gold accents. Accent and background presets can be changed in Settings.
- Task and challenge XP / gold rewards are user-entered. The app does not impose task reward values.
- Automatic level thresholds are disabled until the user sets an XP-per-level value in Settings. This avoids inventing an unapproved progression formula.
- No Projects or Skills sections are included.
- User-entered names, titles, task names and descriptions are not automatically translated when the interface language changes.

## Notes

This is a debug-build project intended for the user's GitHub Actions APK workflow. The build workflow checks required source files and all 12 bundled audio assets before compiling and uploads the APK as a workflow artifact. The workflow itself must be run in GitHub to confirm a successful Android build in the user's repository. A successful compile does not replace testing on the target Android device.
