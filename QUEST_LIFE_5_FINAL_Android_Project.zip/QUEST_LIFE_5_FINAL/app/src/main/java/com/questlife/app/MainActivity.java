package com.questlife.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Vibrator;
import android.content.Context;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {
    private WebView web;
    private static final int PICK_IMAGE = 42;
    private static final int NOTIFICATION_PERMISSION = 43;
    private static final int PICK_BACKUP = 44;
    private static final int SAVE_BACKUP = 45;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupJson;
    private String pendingBackupLang = "ar";
    private String pendingReminderTime = "19:00";
    private String pendingReminderLang = "ar";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF090B10);
        getWindow().setNavigationBarColor(0xFF090B10);
        web = new WebView(this);
        web.setBackgroundColor(0xFF090B10);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                    .setNegativeButton(android.R.string.cancel, (dialog, which) -> result.cancel())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain"});
                startActivityForResult(intent, PICK_BACKUP);
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        ReminderReceiver.createChannel(this);
    }

    private class Bridge {
        @JavascriptInterface public void exportBackup(String json, String language) {
            runOnUiThread(() -> {
                pendingBackupJson = json == null ? "{}" : json;
                pendingBackupLang = language == null ? "ar" : language;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "quest-life-5-backup.json");
                startActivityForResult(intent, SAVE_BACKUP);
            });
        }
        @JavascriptInterface public void chooseImage(String ignored) {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                startActivityForResult(intent, PICK_IMAGE);
            });
        }
        @JavascriptInterface public void vibrate(int ms) {
            runOnUiThread(() -> {
                try {
                    Vibrator vibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
                    if (vibrator != null) {
                        if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(android.os.VibrationEffect.createOneShot(Math.max(10, Math.min(ms, 250)), android.os.VibrationEffect.DEFAULT_AMPLITUDE));
                        else vibrator.vibrate(Math.max(10, Math.min(ms, 250)));
                    }
                } catch (Exception ignored) { }
            });
        }
        @JavascriptInterface public void scheduleReminder(String time, boolean enabled, String language) {
            runOnUiThread(() -> {
                if (!enabled) { ReminderReceiver.cancel(MainActivity.this); return; }
                pendingReminderTime = time == null ? "19:00" : time;
                pendingReminderLang = language == null ? "ar" : language;
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
                } else {
                    ReminderReceiver.schedule(MainActivity.this, pendingReminderTime, pendingReminderLang);
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_BACKUP) {
            if (filePathCallback != null) {
                Uri[] result = resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }
        if (requestCode == SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (java.io.OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    if (output == null) throw new IllegalStateException("Cannot open backup destination");
                    output.write(pendingBackupJson.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    web.evaluateJavascript("window.showToast&&window.showToast(" + org.json.JSONObject.quote("ar".equals(pendingBackupLang) ? "تم تصدير النسخة الاحتياطية" : "Backup exported successfully") + ")", null);
                } catch (Exception e) {
                    web.evaluateJavascript("window.showToast&&window.showToast(" + org.json.JSONObject.quote("ar".equals(pendingBackupLang) ? "تعذر حفظ النسخة الاحتياطية" : "Could not save backup") + ")", null);
                }
            }
            pendingBackupJson = null;
            return;
        }
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri uri = data.getData();
                // Convert the selected image to a data URI for the WebView.
                android.graphics.BitmapFactory.Options bounds = new android.graphics.BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                java.io.InputStream boundsStream = getContentResolver().openInputStream(uri);
                android.graphics.BitmapFactory.decodeStream(boundsStream, null, bounds);
                boundsStream.close();
                int sample = 1;
                while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > 1400) sample *= 2;
                android.graphics.BitmapFactory.Options options = new android.graphics.BitmapFactory.Options();
                options.inSampleSize = sample;
                java.io.InputStream imageStream = getContentResolver().openInputStream(uri);
                android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeStream(imageStream, null, options);
                imageStream.close();
                if (bitmap == null) throw new IllegalStateException("Image decode failed");
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, out);
                bitmap.recycle();
                String encoded = android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP);
                String dataUri = "data:image/jpeg;base64," + encoded;
                web.evaluateJavascript("window.onNativeImage&&window.onNativeImage(" + org.json.JSONObject.quote(dataUri) + ")", null);
            } catch (Exception e) {
                web.evaluateJavascript("window.showToast&&window.showToast('Unable to open image')", null);
            }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            ReminderReceiver.schedule(this, pendingReminderTime, pendingReminderLang);
        }
    }

    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("window.handleBack&&window.handleBack()", null);
        else super.onBackPressed();
    }
}
